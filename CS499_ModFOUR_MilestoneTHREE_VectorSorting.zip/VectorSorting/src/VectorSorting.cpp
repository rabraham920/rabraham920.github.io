//============================================================================
// Name        : VectorSorting.cpp
// Author      : Robin Abraham
// Version     : 1.0
// Copyright   : Copyright © 2017 SNHU COCE
// Description : Vector Sorting Algorithms
//============================================================================

#include <algorithm>
#include <iostream>
#include <time.h>

#include "CSVparser.hpp"

using namespace std;

//============================================================================
// Global definitions visible to all methods and classes
//============================================================================

// forward declarations
double strToDouble(string str, char ch);

// define a structure to hold bid information
struct Bid {
    string bidId; // unique identifier
    string title;
    string fund;
    double amount;
    Bid() {
        amount = 0.0;
    }
};

//============================================================================
// Static methods used for testing
//============================================================================

void displayBid(Bid bid) {
    cout << bid.bidId << ": " << bid.title << " | " << bid.amount << " | "
         << bid.fund << endl;
}

Bid getBid() {
    Bid bid;

    cout << "Enter Id: ";
    cin.ignore();
    getline(cin, bid.bidId);

    cout << "Enter title: ";
    getline(cin, bid.title);

    cout << "Enter fund: ";
    cin >> bid.fund;

    cout << "Enter amount: ";
    cin.ignore();
    string strAmount;
    getline(cin, strAmount);
    bid.amount = strToDouble(strAmount, '$');

    return bid;
}

vector<Bid> loadBids(string csvPath) {
    cout << "Loading CSV file " << csvPath << endl;

    vector<Bid> bids;
    csv::Parser file = csv::Parser(csvPath);

    try {
        for (int i = 0; i < file.rowCount(); i++) {
            Bid bid;
            bid.bidId = file[i][1];
            bid.title = file[i][0];
            bid.fund = file[i][8];
            bid.amount = strToDouble(file[i][4], '$');

            bids.push_back(bid);
        }
    } catch (csv::Error &e) {
        cerr << e.what() << endl;
    }
    return bids;
}

//============================================================================
// Enhance Partition Function
//============================================================================
int partition(vector<Bid>& bids, int begin, int end) {
    int lowIndex = begin;
    int highIndex = end;

    string pivot = bids[begin + (end - begin) / 2].title;

    while (true) {
        while (bids[lowIndex].title < pivot) {
            lowIndex++;
        }
        while (bids[highIndex].title > pivot) {
            highIndex--;
        }

        if (lowIndex >= highIndex) {
            return highIndex;
        }

        swap(bids[lowIndex], bids[highIndex]);

        lowIndex++;
        highIndex--;
    }
}

//============================================================================
// Enhanced Quick Sort
//============================================================================

void quickSort(vector<Bid>& bids, int begin, int end) {
    if (begin >= end) {
        return;
    }

    int pivotIndex = partition(bids, begin, end);

    quickSort(bids, begin, pivotIndex);
    quickSort(bids, pivotIndex + 1, end);
}

//============================================================================
// Selection Sort
//============================================================================
void selectionSort(vector<Bid>& bids) {
    for (size_t i = 0; i < bids.size() - 1; i++) {
        size_t minIndex = i;

        for (size_t j = i + 1; j < bids.size(); j++) {
            if (bids[j].title < bids[minIndex].title) {
                minIndex = j;
            }
        }

        if (minIndex != i) {
            swap(bids[i], bids[minIndex]);
        }
    }
}

//============================================================================
// Utility Function
//============================================================================
double strToDouble(string str, char ch) { // Convert to String Double
    str.erase(remove(str.begin(), str.end(), ch), str.end());
    return atof(str.c_str());
}

//============================================================================
// Main Function
//============================================================================
int main(int argc, char* argv[]) {
    string csvPath;
    switch (argc) {
        case 2:
            csvPath = argv[1];
            break;
        default:
            csvPath = "eBid_Monthly_Sales_Dec_2016.csv";
    }

    vector<Bid> bids;
    clock_t ticks;
    int choice = 0;

    while (choice != 9) {
        cout << "Menu:" << endl;
        cout << "  1. Load Bids" << endl;
        cout << "  2. Display All Bids" << endl;
        cout << "  3. Selection Sort All Bids" << endl;
        cout << "  4. Quick Sort All Bids" << endl;
        cout << "  9. Exit" << endl;
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                ticks = clock();
                bids = loadBids(csvPath);
                cout << bids.size() << " bids read" << endl;
                ticks = clock() - ticks;
                cout << "Time: " << ticks << " clock ticks" << endl;
                cout << "Time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
                break;

            case 2:
                for (int i = 0; i < bids.size(); ++i) {
                    displayBid(bids[i]);
                }
                cout << endl;
                break;

            case 3:
                ticks = clock();
                selectionSort(bids);
                cout << bids.size() << " bids sorted" << endl;
                ticks = clock() - ticks;
                cout << "Time: " << ticks << " clock ticks" << endl;
                cout << "Time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
                break;

            case 4:
                ticks = clock();
                quickSort(bids, 0, bids.size() - 1);
                cout << bids.size() << " bids sorted" << endl;
                ticks = clock() - ticks;
                cout << "Time: " << ticks << " clock ticks" << endl;
                cout << "Time: " << ticks * 1.0 / CLOCKS_PER_SEC << " seconds" << endl;
                break;
        }
    }

    cout << "Goodbye." << endl;
    return 0;
}
